#include "Bird.h"
#include "helpers_main.h"

void Bird::set_color(std::string _color)
{
    color = _color;
};
void Bird::set_can_speak(bool _speak)
{
    can_speak = _speak;

};
std::string Bird::get_color()const
{
    return color;
};
bool Bird::get_can_speak()const
{
    return can_speak;
};

std::string Bird::get_type()const
 {
     return type;
 };




Bird::Bird() // default Dog constructor when a named is NOT passed in
:Pet()
{
    color = "None";
};
Bird::Bird(std::string s, int ss, int i,std::string _color)
: Pet(s,ss,i)
{
    if(_color == "") color = "none";
    else color = _color;
};


int Bird::get_grooming() const
{
    return grooming;
};
int Bird::get_checkups() const
{
    return checkups;
};