#include "Pet.h"
#ifndef BIRD_H
#define BIRD_H
class Bird: public Pet
{
    public:
    Bird(); // creates an instance of a Dog, with empty string and an ID# and days at 0
    Bird(std::string,int, int,std::string);
    void set_color(std::string);
    void set_can_speak(bool);
    virtual std::string get_color()const;
    virtual bool get_can_speak()const;
    virtual std::string get_type()const;
    virtual int get_grooming() const;
    virtual int get_checkups() const;
    const std::string type = "Bird";
    
    private:
    std::string color;
    bool can_speak;
    
    int grooming = 2;
    int checkups = 7;
    int current_checkups;
    int current_grooming;
};
#endif