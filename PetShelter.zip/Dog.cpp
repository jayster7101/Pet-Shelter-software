#include "Dog.h"
void Dog::set_breed(std::string _breed)
{
    breed = _breed;
};
void Dog::set_fav_toy(std::string _toy)
{
    fav_toy = _toy;
};
std::string Dog::get_breed()const
{
    //std::cout << "Get_breed should be dog \n";
    return breed;
};

Dog::Dog() // default Dog constructor when a named is NOT passed in
:Pet()
{
}
Dog::Dog(std::string s, int ss, int i)
: Pet(s,ss,i)
{
}

std::string Dog::get_fav_toy()const 
{
    return fav_toy;
}

std::string Dog::get_type()const
 {
     return type;
 };


int Dog::get_grooming() const
{
    return grooming;
};
int Dog::get_checkups() const
{
    return checkups;
};

// void Dog::perfrom_checkup()
// {
//     if(this.)
// };