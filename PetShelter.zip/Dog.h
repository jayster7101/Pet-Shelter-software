#include "Pet.h"
#ifndef DOG_H
#define DOG_H
class Dog : public Pet
{
    public:
    Dog(); // creates an instance of a Dog, with empty string and an ID# and days at 0
    Dog(std::string,int, int);
    void set_breed(std::string);
    // std::string get_type()const;
    void set_fav_toy(std::string);
    virtual std::string get_breed()const;
    virtual std::string get_fav_toy()const;
    virtual std::string get_type()const;
    const std::string type = "Dog";

    virtual int get_grooming() const;
    virtual int get_checkups() const;
    // virtual void perfrom_checkup();
     
    private:
    std::string breed;
    std::string fav_toy;
    int grooming = 3;
    int checkups = 7;
    int current_checkups;
    int current_grooming;
};
#endif