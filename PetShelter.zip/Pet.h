#include "includes.h"
#ifndef PET_H
#define PET_H

class Pet {
    public:
    Pet(); // creates an instance of a pet, with empty string and an ID# and days at 0
    Pet(std::string,int, int); // creates an instance of a pet, assigns the name, the ID# and the days the pet has been in shelter
    std::string get_name() const; // returns the name of animal in string format
    double get_weight() const; // returns type double of weight
    int get_id() const; // returns the ID number if that instance of the pet
    int get_days() const; // returns the amount days that the pet has been in the shelter 
    void set_name(); // changes the name if the name is set to ""
    void set_weight(double); // sets the weight of the animal
    void set_age(double);  // !!!NEW!!!
    double get_age() const; // !!!NEW!!!
    virtual std::string get_breed() const;
    virtual std::string get_fav_toy()const;
    virtual std::string get_color()const;
    virtual bool get_can_speak()const;
    virtual std::string get_type()const;

    virtual int get_grooming() const;
    virtual int get_checkups() const;
    virtual void perfrom_checkup();

    // DELETE  std::string get_type() const; // returns the type of animal in string format
    // DELETE void set_type(std::string); // changes the type if the type is set to ""
    
    private:
    int create_id(); // creates a random id with a length of 5 digits   !!!!!!****CHANGE TO A MAPPING ****!!!!!
    //type,name, double weight, int id, int days
    double age;
    std::string name;
    double weight = 0.0;
    int id;
    int days = 0;
};
#endif