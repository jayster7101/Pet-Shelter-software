#include "helpers_main.h"

int amount;
std::string local_file = "0______0";


/**
 * @brief gets the name of the file
 * has a fail safe for when the users file doesnt exist and asks if they would like to postpone this operation tell later
 * used for reading in from a text file
 * @param  NONE
 * @return string of the files name or defaults to  "nofile"
 */
    std::string get_file()
    {
        int count = 0;
        std::string _file;
        std::cout << "You stated that you have current inventroy.\n Please input the files name to access that data\n> ";
        std::cin >> _file;
        std::ifstream file;
        file.open(_file);
        while(file.fail())
        {
           count++;
           std::cout<< "It seems that that file does not exist please try again\n> ";
           std::cin >> _file;
           file.open(_file);
           if(!file.fail())
           {
               file.clear();
           }
           if(count == 4)
            {
                std::cout << "It seems that you are having trouble opening a file, would you like for us to bypass this and create a new file later on instead?\nPlease enter yes or no\n>";
                bool _enter = enter();
                if(_enter)
                {
                    _file = "nofile";
                    return _file;
                }
                count = 0;

            }
        }
        local_file = _file;
        return _file;
    };

/**
 * @brief greets the user and explains the program
 * then it asks if they would like to enter the program
 * @param  NONE
 * @return NONE
 */
    void greet()
    {
         std::cout << "Hello Welcome to pet shelter express! We provide top of the line software for pet shelters all over the united states\n";
         std::cout << "Would you like to enter the program?\n";
         std::cout<< "Please enter yes or no?\n> ";
    }

/**
 * @brief gets the users responce to yes or no questions
 * @param  NONE
 * @return bool true if the answer is yes, false if the answer is no
 */
bool enter()
{
    bool return_value;
    std::string yes_no;
    bool reprompt = false;
        while(!reprompt) // this is the first instance of input validation which only accepts yes or Yes or No or no and will keep prompting until valid
        {
            if(std::cin.fail()) std::cin.ignore(100,'\n'); // ignores the flag on the error 
            std::cin >> yes_no;
            if(yes_no =="yes" || yes_no =="Yes")// the logic below compares the string to the 4 possible values, and then returns true or false to either enter the if statement or skip to the else statement in the main function
            {
                reprompt = true;
                return_value = true;
            }
            else if (yes_no =="no" || yes_no =="No")
            {
                reprompt = true;
                return_value = false;
            }
            else
            {
                std::cout<<"Please enter yes or no only\n> ";
            }
        }
    return return_value;
}

/**
 * @brief greets the user if they have inventory and then call the enterr function to get their responce 
 * @param  NONE
 * @return bool 
 */
bool filepath()
{
    std::cout << "Do you have inventory that needs to be accounted for?\nPlease enter yes or no\n> ";
    bool pick = enter();
    return pick;
}

/**
 * @brief This function work along side parse_reader, this first part gets the users .txt file and opens an input file stream
 * it then uses the getline method to get each line of the stream from the .txt file
 * it then passes each line into the parse_reader with the index of the next available spot in the array 
 * also passes in the line from get line and the pets array
 * @param  *pets [pointer to the array of type Pet]
 * @return NONE 
 */
void read_write (Pet **pets)
{
    std::string file = get_file(); // gets a file
    if(file == "nofile")
    {
        return;
    }
    std::ifstream in;
    in.open(file);
    std::string get_line;
    int count = 0;
    std::string _amount;
    getline(in,_amount);
    amount = stoi(_amount);
    while(getline(in,get_line) && amount <= MAX && count < MAX)
    {
        parse_reader(get_line , pets, count);
        count++;
    }
}
/**
 * @brief This function works along side read_write
 * it takes the line and opens a string stream with the value passsed in from the read_write function
 * it assigns values from the text file to their appropriate values and then creates an instance of an object with those specified values 
 * lastly it pushes that object into the Pet pets array
 * @param  *pets [pointer to the array of type Pet], _text from the getline in read_write, count to know where we are in the array
 * @return NONE 
 */
void parse_reader(std::string _text, Pet **pets, int count) {
        std::string type;
        double age;
        std::string name;
        int days;
        double weight;
        int id;
        std::string breed;
        std::string fav_chew_toy;
        std::string color;
        bool speak;
        std::stringstream ss (_text);
        ss >> type;// >> name >> age >> days >> weight >> id;
        if(type == "Bird")
        {
            ss >> name >> age >> days >> weight >> id >> color >> speak;
            Bird *bird= new Bird(name,id,days,color);
            bird->set_age(age);
            bird->set_weight(weight);
            bird->set_can_speak(speak);
            pets[count] = bird;
        }
        else
        {
            ss >> name >> age >> days >> weight >> id  >> fav_chew_toy >> breed;
            Dog *dog= new Dog(name,id,days);
            dog->set_age(age);
            dog->set_weight(weight);
            dog->set_fav_toy(fav_chew_toy);
            dog->set_breed(breed);
            pets[count] = dog;
        }
        //out << pets[i].get_type() << " " << pets[i].get_name() << " " << pets[i].get_age() << " " <<  pets[i].get_days()+1 << " " << pets[i].get_weight() << " " << pets[i].get_id() << pets[i].get_color() << " " << pets[i].get_can_speak() << "\n";
        //std::cout << type <<" " <<  name << " " << days << " " << weight << " " << id << "\n";

        // Pet pet(name,id,days);
        // pet.set_age(age);
        // pet.set_weight(weight);
        // pets[count] = pet;
}

void print_array (Pet *pets)
{
    for(int i = 0; i < amount; i++)
    {
        std::cout << pets[i].get_age() <<" " <<  pets[i].get_name() << " " <<  pets[i].get_days() << " " << pets[i].get_weight() << " " << pets[i].get_id() << "\n";
    }
}
/**
 * @brief This function adds a pet to the array, 
 * it displays how many available spots are in the shelter, 
 * it gets all the relevant information with input validation and then pushes that object to the pets array 
 * if the max limit is reached then it displays helpful information and then calls the write_array function to handle saving the data
 * @param  *pets [pointer to the array of type Pet]
 * @return bool true if more pets can be added and false if the shelter is full
 */
bool add_pet(Pet **pets)
{
    //std::cout << "pets array index zero " << pets[];
    bool temp = false;

    while(amount != 10 && !temp )
    {
        //Bird *bird = new Bird;
        printBox();
        std::cout << "There are currently " << MAX-amount << " available spots.\n";
        std::cout << "Would you like to add an animal to the shelter?\n> ";
        bool ask = enter();
        if(ask)
        {
            std::string animal_type = pick_animal();
            if(animal_type == "Bird")
            {
                Bird *bird = add_pet_Bird();
                pets[amount] = bird;
                //std::cout << pets[0]->get_color();
                amount++;
            }
            else 
            {
                Dog *dog = add_pet_Dog();
                pets[amount] = dog;
                amount++;
            }
            // pet->set_name();
            // double age;
            // double weight;
            // std::cout << "What is the estimated age of this animal?\n> ";
            // age = get_double();
            // pet->set_age(age);
            // std::cout << "How much does " << pet->get_name() << " Weigh in pounds?\n> ";
            // std::cin >> weight;
            //     while(std::cin.fail())
            //     {
            //     std::cin.clear();
            //     std::cin.ignore(100, '\n');
            //     std::cout<<"sorry please enter a number\n>";
            //     std::cin >> weight;
            //     }
            
            // // pet->set_breed("Test");
            // pets[amount] = *pet; //WORRY

            // amount++;
        } else 
        {
            temp = true; 
        }
    }
            printBox();
            if (amount == 10)
            {
                helpful_info();
                write_array(pets);
                return false;
            }
            else 
            {
                return true;
            }
}

/**
 * @brief gets the users decision on saving the data or not 
 * double checks before erasing any data
 * asks if the user wants to use the same file they read in from if applicable or asks for the new files name 
 * lastly it opens an output file stream and writes all data to the txt file
 * @param  *pets [pointer to the array of type Pet]
 * @return NONE 
 */
void write_array(Pet **pets)
{
    std::ofstream out;
    std::cout << "Would you like to save this data to a txt file ?\n>";
    bool go = enter();
    if(!go) 
    {
        std::cout << "Are you sure you dont want to save this data? All of it will be destroyed!!! Enter yes to destory data\n>";
        bool _enter = enter();
        if(_enter)
        {
            std::cout << "All data is not saved has since been purged!!!\n";
        }
        else
        {
            go = true;
        }
    }
    if(go)
    {
        if(local_file == "0______0")
        {
            std::string file;
            std::cout << "What you like to name this file?\n>";
            std::cin >> file;
            out.open(file+=".txt");
        }
        else 
        {
            std::cout << "Would you like to use the file named " << local_file <<" to save the data?\n>";
            bool _enter = enter();
            if(_enter)
            {
                out.open(local_file);
            }
            else 
            {
            std::string file;
            std::cout << "What would you like to name this file?\n>";
            std::cin >> file;
            out.open(file+=".txt");
            }
        }
    }
    out << amount <<"\n";
    for(int i = 0; i < amount; i++) // ss >> type >> name >> age >> days >> weight >> id;
    {
        if(pets[i]->get_type() == "Bird")
        {
           out << pets[i]->get_type() << " " << pets[i]->get_name() << " " << pets[i]->get_age() << " " <<  pets[i]->get_days()+1 << " " << pets[i]->get_weight() << " " << pets[i]->get_id() << " " << pets[i]->get_color() << " " << pets[i]->get_can_speak() << "\n";
        }
        else
        { 
            out << pets[i]->get_type() << " " << pets[i]->get_name() << " " << pets[i]->get_age() << " " <<  pets[i]->get_days()+1 << " " << pets[i]->get_weight() << " " << pets[i]->get_id()<< " " << pets[i]->get_fav_toy() << " " << pets[i]->get_breed() << "\n";
        }  
    }
    
}
// outputs a simple helpul/meaningful message 
void helpful_info()
{
    std::cout << "It seems that our shelter is at max capacity and isn't accepting any new animals.\nAnother great shelter is located just down the road at 1950 Stevenson Blvd, Fremont, CA 94538\nThey are open from 11:00am to 4:00pm Monday through Thursday.\nWe suggest getting ahold of them before driving down there, their phone number is : (510) 790-6640\n";
}


/**
 * @brief finds the pet who has been in the shelter the longest by searching through the entire array and checking against the known largest or replacing the largest
 * @param  *pets [pointer to the array of type Pet]
 * @return Pet  
 */

int find_a_home(Pet **pets)
{
    int longest = 0;
    int temp = 0;
    for (int i = 0; i < amount; i++)
    {
        if(pets[i]->get_days() > longest)
        {
            temp = i;
            longest = pets[i]->get_days();
        }
    }
    return temp;
}

/**
 * @brief displays the animal thats been in the shelter the longest, 
 * used along side find_a_home, which gets the index of the animal thats been in the shelter the longest 
 * then prints the relevant information
 * @param  *pets [pointer to the array of type Pet]
 * @return NONE 
 */
void find(Pet **pets)
{
    std::cout << "Would you like to see the animal who has been in the shelter the longest?\n>";
    bool _enter = enter();
    if(_enter)
    {
        int index = find_a_home(pets);
        std::cout << pets[index]->get_name() << " the " << pets[index]->get_type() << " has been in this shelter for " << pets[index]->get_days() << " days!\nBe his savior and adopt him.\n";
    }

}

void no_enter()
{
    std::cout << "Thank you for your time and have a good day.\n";
}

void printBox()
{
    std::cout << "-----------------------------------------------------\n";
}

/**
 * @brief gets a type double from user 
 * built in error handeling 
 * @return double 
 */
double get_double()
{
    double _double;
    std::cin >> _double;
    while(std::cin.fail() || (_double < 1))
    {
        if(_double < 1)
        {
            std::cout << "Sorry numbers under 1 are not accepted\n";
        }
        std::cin.ignore(100,'\n');
        
        std::cout << "Please enter a number only Ex:(1,3.4,45.78)\n>";
        std::cin >> _double;
        std::cin.clear();
        
    }
    return _double;
}

/**
 * @brief gets the users animal they are putting into shelter 
 * checks to see if they are adding the right type of animal
 * 
 * @return string
 */
std::string pick_animal() 
{
    int array_size = (sizeof(list) / (sizeof(list[0])));
    std::cout << "Which type of animal would you like to enter into the shelter?\nWe are currently only accepting ";
    for(int i = 0; i < array_size; i++)
    {
        std::cout << list[i];
        if(i != array_size-1)
        {
            std::cout <<"s, ";
        }
        else std::cout << "s!\n";
    }
    std::string user;
    std::cin >> user;
    while (!(is_in_array(user, list)))
    {
        std::cout << "Sorry we aren't accepting " << user << ". Only ";
        for(int i = 0; i < array_size; i++)
    {
        std::cout << list[i];
        if(i != array_size-1)
        {
            std::cout <<", ";
        }
        else std::cout << "!\n";
    }
    std::cin >> user;
    }
    return user;
}

/**
 * @brief checks to see if a type string is in an array of strings 
 * 
 * @param in 
 * @param array 
 * @return true 
 * @return false 
 */
bool is_in_array(std::string in, const std::string array[])
{
    int size = (sizeof(list) / (sizeof(list[0])));
    for(int i = 0; i < size; i ++)
    {
        if(in == array[i])
        {
            return true;
        }
    }
    return false;
}



Bird* add_pet_Bird ()
{
    Bird *bird = new Bird();
    bird->set_name();
    double age;
    double weight;
    std::cout << "What is the estimated age of this animal?\n> ";
    age = get_double();
    bird->set_age(age);
    std::cout << "How much does " << bird->get_name() << " Weigh in pounds?\n> ";
    std::cin >> weight;
    while(std::cin.fail())
    {
        std::cin.clear();
        std::cin.ignore(100, '\n');
        std::cout<<"sorry please enter a number\n>";
        std::cin >> weight;
    }
    bird->set_weight(weight);
    std::string color;
    std::cout << "What color is this bird?\n>";
    std::cin >> color;
    bird->set_color(color);
    bool input;
    std::cout << "Can the bird speak?\n>";
    input = enter();
    bird->set_can_speak(input);
    return bird;
}

Dog* add_pet_Dog ()
{
    Dog *dog = new Dog();
    dog->set_name();
    double age;
    double weight;
    std::cout << "What is the estimated age of this animal? Ex: 15.5\n> ";
    age = get_double();
    dog->set_age(age);
    std::cout << "How much does " << dog->get_name() << " Weigh in pounds? Ex: 27.3\n> ";
    weight = get_double();
    dog->set_weight(weight);
    std::string toy;
    std::cout << "Whats the dogs favorite toy? Ex: ball,kong,TugOWar\n>";
    std::cin >> toy;
    dog->set_fav_toy(toy);
    std::string breed;
    std::cout << "Whats breed is the dog? Ex:German_shepard,PitBull,yorkie\n>";
    std::cin >> breed;
    dog->set_breed(breed);
    return dog;
}
/**
 * @Dev
 * Left off at is_in_array
 * Make allow it to be passed an array
 * currently doesnt work, and only works with the global array
 * array[] does nothing
 * 
 * future plans***************
 * 
 * Once i can get the user to be able to pick the type of animal 
 * we will make a function that gets all of the relevant data for the new pets
 * they are classes that use inheritance so idk if I you can use a overloaded function that can tell from the diffrent sub classes of pets
 * if possible make two overloaded function that checks for class Dog and Bird and then enter each accrodingly 
 * HAV CHANGED PARSE ARRAY ADDED TYPE TO IN FROM .TXT FILE
 * 
 */


// ADD ADOPTER LIST AND array 
// create adopter list 
// function adopters to check against whos in the array 



// Grooming maintance function
//checkup maintance function