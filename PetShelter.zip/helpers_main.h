//#include "includes.h"
#include "Pet.h"
#include "Dog.h"
#include "Bird.h"
#ifndef HELPERS_MAIN_H
#define HELPERS_MAIN_H
const int MAX = 20;
const std::string list[] = {"Bird","Dog"};


// *****NON MEMBER FUNCTIONS*****

std::string get_file(); // gets and returns file as a string 
void greet();// simple greeting
bool enter(); // takes users input for yes and no questions and returns a bool 
bool filepath();// asks if the user has a file and calls enter()
void read_write(Pet **pets); // creates an input file stream and calls parse_reader to parse data into an array
void parse_reader(std::string,Pet **pets, int count); // parses data into the array
void print_array(Pet **pets); // prints the array of whats available
bool add_pet(Pet **pets); // adds an instance of a pet to the pets array at the next relevent position
void write_array(Pet **pets); //opens an outstream to write to, asks for file name or if a file was used to read in then it asks to use that one
void helpful_info();// writes helpful information to the console
int find_a_home(Pet **pets); // finds the animal that has been in the shelter the longest 
void find(Pet **pets);// asks if the user wants to find the animal that has been in the shelter the longest and then calls find_a_home
void no_enter(); // default information when the user deices to not enter the program 
void printBox();


Bird* add_pet_Bird();
Dog* add_pet_Dog();
double get_double(); // checks to make sure data is of type double and in this case bigger than 0

std::string pick_animal();
bool is_in_array(std::string, const std::string[]); // returns true if a certain string is in array of strings
#endif