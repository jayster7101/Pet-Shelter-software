#ifndef INCLUDES_H
#define INCLUDES_H

#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>     
#include <fstream>
#include <sstream>
#include <ctime>

#endif