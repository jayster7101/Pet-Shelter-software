/*
From: Jayden Jardine
Date: 02/18/2022
Description: This a simple business-oriented software for a small animal shelter. 
The shelter will be able to hold up to ten animals and store their name, type of animal, identification number, amount of days they have been in the shelter, and weight. 
you can read and write to a file which acts as saving the data anf updating inventroy 
as well find which animal has been in the shelter the longest
*/
#include "helpers_main.h"
#include "Pet.h"
#include "Mix.h"

int main()
{
    // std::string ttt = pick_animal();
    // std::cout << ttt;\

    Pet *pets[20];

    //pets[0]->set_breed("trest");
    greet();
    // Dog* D = new Dog;
    // D->set_breed("pitbull");
    // std::cout << " pets should be pit " << D->get_breed();
    // pets[0]= D;
    // std::cout <<"pets at sero " << pets[0]->get_breed();

    //std::cout << pets[0].get_breed();
    bool _enter = enter();
    if(_enter)
    {
        bool path = filepath();
        if(path)
        {
         //std::cout << "in main " << pets[0] << " " << &pets[0];   
            read_write(pets);

        }
        bool add = add_pet(pets);
        if(add) write_array(pets);
        find(pets);
    }
    else no_enter();
}

