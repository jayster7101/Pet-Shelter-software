// File holds all of the necessary #include statments
#ifndef INCLUDES_H
#define INCLUDES_H

#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>     
#include <fstream>
#include <sstream>
#include <ctime>
#include "Adopters.h"
#include <vector>
#include "Pet.h"
#include "helpers_main.h"
#include "Dog.h"
#include "Bird.h"

#endif